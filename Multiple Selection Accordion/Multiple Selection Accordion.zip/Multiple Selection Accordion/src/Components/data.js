const data = [
    {
        "question": "What is the capital of France?",
        "answer": "Paris"
    },
    {
        "question": "Who wrote 'To Kill a Mockingbird'?",
        "answer": "Harper Lee"
    },
    {
        "question": "What is the chemical symbol for water?",
        "answer": "H2O"
    },
    {
        "question": "Who was the first president of the United States?",
        "answer": "George Washington"
    },
    {
        "question": "What is the largest planet in our solar system?",
        "answer": "Jupiter"
    },
    {
        "question": "What is the smallest prime number?",
        "answer": "2"
    },
    {
        "question": "What year did the Titanic sink?",
        "answer": "1912"
    },
    {
        "question": "Who painted the Mona Lisa?",
        "answer": "Leonardo da Vinci"
    },
    {
        "question": "What is the hardest natural substance on Earth?",
        "answer": "Diamond"
    },
    {
        "question": "What is the speed of light?",
        "answer": "299,792,458 meters per second"
    }
]

export default data;