import Heading from "./assets/components/Heading";
import ToDoComponent from "./assets/components/ToDoComponent";
import InputBox from "./assets/components/InputBox";
import { useState } from "react";

function App() {
  let initialTasks = [
    { id: 1, task: "Finish report", due_date: "2024-07-05" },
    { id: 2, task: "Call client", due_date: "2024-07-03" },
    { id: 3, task: "Email team updates", due_date: "2024-07-02" },
    { id: 4, task: "Review project proposal", due_date: "2024-07-07" },
    { id: 5, task: "Prepare presentation", due_date: "2024-07-10" }
  ];

  let [taskName, setTaskName] = useState("");
  let [taskDate, setTaskDate] = useState("");
  let [data, setData] = useState(initialTasks);

  function handleAddButton() {
    const newTask = {
      id: data.length + 1,
      task: taskName,
      due_date: taskDate
    };
    setData([...data, newTask]);
    setTaskName('');
    setTaskDate('');
  }

  function handleDeleteButton(id) {
    const updatedTasks = data.filter(task => task.id !== id);
    setData(updatedTasks);
  }

  return (
    <>
      <Heading />
      <InputBox handleAddButton={handleAddButton} taskName={taskName} taskDate={taskDate} setTaskName={setTaskName} setTaskDate={setTaskDate} />
      <ToDoComponent data={data} handleDeleteButton={handleDeleteButton} />
    </>
  );
}

export default App;
