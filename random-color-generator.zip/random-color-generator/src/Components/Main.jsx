export default function Main () {

    const handleOnClick = () => {
        let colorString = '';
        const colors = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F'];
        
        for (let i = 0; i < 6; i++) {
            let randomIndex = Math.floor(Math.random() * colors.length);
            colorString = colorString + colors[randomIndex];
        }
        colorString = '#' + colorString;
        document.getElementById("hex-color-box").style.backgroundColor = colorString;
        document.getElementById("hex-color").innerHTML = colorString;
    }

    return <div className="w-75 m-auto my-5 h-75 rounded d-flex justify-content-center align-items-center p-5 flex-column" id = 'hex-color-box'>
        <button className="btn btn-dark my-5" onClick={() => handleOnClick()}>Click here to generate color</button>
        <p className="my-5 fw-bold" id="hex-color">#000000</p>
    </div>
}