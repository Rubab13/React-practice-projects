function Heading() {
    return <h1 className="text-center mt-3 mb-5">My Accordian</h1>
}

export default Heading;