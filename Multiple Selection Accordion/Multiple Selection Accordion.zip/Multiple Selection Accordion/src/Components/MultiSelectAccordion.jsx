import data from './data';
import AccordionBox from './AccordionBox';
import { useState } from 'react';

export default function MultiSelectAccordion() {
    let [selectedIndex, setSelectedIndex] = useState([]);

    const handleClick = (index) => {
        if (selectedIndex.includes(index)) {
            let result = selectedIndex.filter((item) => item !== index);
            setSelectedIndex(result);
        } else {
            setSelectedIndex([...selectedIndex, index]);
        }
    };

    return (
        <div className="border p-2 m-3 rounded">
            {data.map((item, index) => (
                <AccordionBox
                    question={item.question}
                    answer={item.answer}
                    isSelected={selectedIndex.includes(index)}
                    handleClick={() => handleClick(index)}
                    index={index}
                    key={index}
                />
            ))}
        </div>
    );
}
