export default function Button (props) {
    return (
        <button 
            className="bg-info-subtle border-0 rounded-2 p-5 my-2 mx-3"  
            onClick={props.handleClick} 
            style={{fontSize:"1.2rem"}}
        >
            {props.item}
        </button>
    );
}
