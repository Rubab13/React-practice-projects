import ToDoItem from "./ToDoItem";

function ToDoComponent(props) {
    return (
        <div className="w-75 m-auto rounded border p-2">
            {props.data && props.data.map(item => (
                <ToDoItem
                    key={item.id}
                    item={item}
                    handleDeleteButton={props.handleDeleteButton}
                />
            ))}
            {props.data.length === 0 && <p className="text-center font-weight-bold my-3">You are good for today.{<br/>}No pending Tasks.</p>}
        </div>
    );
}

export default ToDoComponent;
