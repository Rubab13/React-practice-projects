export default function Heading (props) {
    return <div className="p-3 bg-warning-subtle m-3 rounded border shadow">
        <h1 className="text-center">{props.heading}</h1>
    </div>
}