function Heading () {
    return <h1 className="my-5 text-center">TO Do List</h1>
  }
  
  export default Heading;