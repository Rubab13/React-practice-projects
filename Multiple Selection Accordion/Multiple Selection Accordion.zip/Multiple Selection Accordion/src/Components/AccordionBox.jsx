function AccordionBox(props) {
    return (
        <div
            className="container bg-info-subtle p-3 m-auto rounded my-3"
            style={{ cursor: 'pointer' }}
            onClick={props.handleClick}
        >
            <p className="fw-bold h5">{props.question}</p>
            {props.isSelected && <p>{props.answer}</p>}
        </div>
    );
}

export default AccordionBox;
