export default function Heading () {
    return <h1 className="text-center my-5">Calculator</h1>
}