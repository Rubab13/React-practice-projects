import Button from "./Button";

export default function CalculatorComponent (props) {
    let array = [1, 2, 3, 4, 5, 6, 7, 8, 9, 0, "+", "-", "*", "/", "=", "C"];
    return (
        <div className="border rounded-4 d-flex flex-wrap p-2 justify-content-center m-auto w-50 mb-5">
            {array.map((item, index) => (
                <Button 
                    key={index} 
                    handleClick={() => props.handleClick(item)} 
                    item={item} 
                />
            ))}
        </div>
    );
}
