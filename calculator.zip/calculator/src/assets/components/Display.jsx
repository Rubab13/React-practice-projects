export default function Display (props) {
    return <div className="bg-dark text-light p-5 w-50 m-auto mb-3 rounded" style={{fontSize:"2rem"}}>
        {props.display}
    </div>
}
