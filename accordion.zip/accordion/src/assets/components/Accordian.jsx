function Accordion({ data, handleClick, isSelected }) {
    return (
        <div className="border p-2 w-75 m-auto rounded" style={{ cursor: 'pointer' }}>
            {data && data.map((item) => (
                <div
                    className="bg-info-subtle mt-2 p-3 rounded"
                    key={item.id}
                    onClick={() => handleClick(item.id)}
                >
                    <p style={{ fontWeight: 'bold', fontSize: '1.1rem' }}>{item.question}</p>
                    {isSelected === item.id && (
                        <div className="mt-2">
                            {item.answer}
                        </div>
                    )}
                </div>
            ))}
        </div>
    );
}

export default Accordion;
