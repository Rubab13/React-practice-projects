import Heading from "./Components/Heading";
import Main from "./Components/Main";

export default function App () {
    return (
        <>
            <Heading/>
            <Main/>
        </>
    );
}