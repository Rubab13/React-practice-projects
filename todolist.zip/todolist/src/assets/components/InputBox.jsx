export default function InputBox(props) {

    const handleTaskNameChange = (event) => {
        props.setTaskName(event.target.value);
    };
    
    const handleTaskDateChange = (event) => {
        props.setTaskDate(event.target.value);
    };

    return <div className="w-75 m-auto rounded border p-2 my-3">
        <div className="bg-warning-subtle rounded p-2 my-2  d-flex justify-content-between align-items-center">
            <input type="text" className="w-50" placeholder="Enter Task Name" value={props.taskName} onChange={handleTaskNameChange}/>
            <input type="date" placeholder="Enter Due Date" value={props.taskDate} onChange={handleTaskDateChange}/>
            <button className="btn btn-success px-4" onClick={() => props.handleAddButton()}>Add</button>
        </div>
    </div>
}