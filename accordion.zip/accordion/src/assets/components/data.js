let array = [
    {
        "id": 1,
        "question": "What are the primary factors contributing to the efficiency of successful YouTube streamers?",
        "answer": "Successful YouTube streamers often excel due to a combination of factors including engaging content, consistent upload schedules, effective use of social media for promotion, strong viewer interaction, and optimizing video titles, descriptions, and tags for search engine optimization (SEO)."
    },
    {
        "id": 2,
        "question": "What is the largest planet in our solar system?",
        "answer": "The largest planet in our solar system is Jupiter. Jupiter is a gas giant with a diameter of about 143,000 kilometers (88,846 miles) and is known for its prominent Great Red Spot, a giant storm that has been raging for centuries. It has at least 79 moons, including the four large Galilean moons: Io, Europa, Ganymede, and Callisto. Jupiter's massive size and strong magnetic field make it a fascinating subject of study in planetary science."
    },
    {
        "id": 3,
        "question": "Who wrote the play 'Romeo and Juliet'?",
        "answer": "'Romeo and Juliet' was written by William Shakespeare, one of the most celebrated playwrights in English literature. This tragic play tells the story of two young lovers whose deaths ultimately reconcile their feuding families. It is one of Shakespeare's most popular works and has been adapted into numerous films, ballets, and other forms of media."
    },
    {
        "id": 4,
        "question": "What is the capital city of France?",
        "answer": "The capital city of France is Paris. Known as the 'City of Light' (La Ville Lumière), Paris is famous for its rich history, culture, and art. It is home to iconic landmarks such as the Eiffel Tower, the Louvre Museum, Notre-Dame Cathedral, and the Champs-Élysées. Paris is also renowned for its fashion, cuisine, and vibrant café culture."
    },
    {
        "id": 5,
        "question": "What is the chemical symbol for water?",
        "answer": "The chemical symbol for water is H₂O. Water is composed of two hydrogen atoms covalently bonded to one oxygen atom. It is essential for all known forms of life and covers about 71% of Earth's surface. Water exists in three states: liquid, solid (ice), and gas (water vapor). Its unique properties, such as its high heat capacity, surface tension, and ability to dissolve many substances, make it vital for various biological and environmental processes."
    }
];

export default array;