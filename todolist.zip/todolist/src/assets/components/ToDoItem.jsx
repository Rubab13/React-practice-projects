export default function ToDoItem(props) {
    return (
        <div className="bg-warning-subtle rounded p-2 my-2 d-flex justify-content-between">
            <div className="w-25 d-flex align-items-center" style={{ fontWeight: "bold" }}>{props.item.id}</div>
            <div className="w-25 d-flex align-items-center">{props.item.task}</div>
            <div className="w-25 d-flex align-items-center">{props.item.due_date}</div>
            <button className="btn btn-danger" onClick={() => props.handleDeleteButton(props.item.id)}>Delete</button>
        </div>
    );
}
