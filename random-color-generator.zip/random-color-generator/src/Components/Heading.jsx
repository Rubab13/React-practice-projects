export default function Heading () {
    return <h1 className="h1 text-center my-5">Random Color Generator</h1>
}