import Heading from "./Components/Heading";
import MultiSelectAccordion from './Components/MultiSelectAccordion'

export default function App() {
  return (
    <>
      <Heading heading={"Multiple Selection Accordion"} />
      <MultiSelectAccordion />
    </>
  );
}