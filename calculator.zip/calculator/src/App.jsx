import Heading from "./assets/components/Heading";
import CalculatorComponent from "./assets/components/CalculatorComponent";
import Display from "./assets/components/Display";
import { useState } from "react";

export default function App() {
  let [display, setDisplay] = useState("");

  function handleClick(item) {
    if (item === "C") {
      setDisplay("");
    } else if (item === "=") {
      try {
        // Use a safer alternative to eval
        let result = Function('"use strict";return (' + display + ')')();
        setDisplay(result.toString());
      } catch (error) {
        setDisplay("Error");
      }
    } else {
      setDisplay(display + item.toString());
    }
  }

  return (
    <>
      <Heading />
      <Display display={display} />
      <CalculatorComponent handleClick={handleClick} />
    </>
  );
}
