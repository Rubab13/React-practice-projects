import 'bootstrap/dist/css/bootstrap.css';
import Heading from './assets/components/Heading';
import Accordian from './assets/components/Accordian';
import data from './assets/components/data'
import { useState } from 'react';

function App () {
  let [selected, setSelected] = useState(null);

  function handleClick (id) {
    if (id === selected) {
      setSelected(null);
    }
    else {
      setSelected(id);
    }
  }
  return (
    <>
      <Heading/>
      <Accordian data={data} handleClick={handleClick} isSelected={selected}/>
    </>
  );
}

export default App;